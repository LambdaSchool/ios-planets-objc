//
//  main.m
//  Planets Obj-C
//
//  Created by Audrey Welch on 2/25/19.
//  Copyright © 2019 Audrey Welch. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

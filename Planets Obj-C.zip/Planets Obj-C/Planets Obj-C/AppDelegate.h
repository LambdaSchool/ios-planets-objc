//
//  AppDelegate.h
//  Planets Obj-C
//
//  Created by Audrey Welch on 2/25/19.
//  Copyright © 2019 Audrey Welch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

